mdlr('enge:psx:toolgame', m => {

  const fetchBinary = async (url) => {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Falha ao carregar ${url}`);
    return await response.arrayBuffer();
  }

  const simulateFileSelect = async (arrayBuffer, filename) => {
    const blob = new Blob([arrayBuffer], { type: 'application/octet-stream' });
    const file = new File([blob], filename);

    // Dispara evento para o emulador processar
    const inputElem = document.getElementById('file');
    if (inputElem) {
      const dt = new DataTransfer();
      dt.items.add(file);
      inputElem.files = dt.files;

      const event = new Event('change', { bubbles: true });
      inputElem.dispatchEvent(event);
    }
  }

  const autoLoad = async (biosURL = 'bios.bin', gameURL = 'game.bin') => {
    try {
      const biosBuffer = await fetchBinary(biosURL);
      console.log('BIOS carregada');

      const gameBuffer = await fetchBinary(gameURL);
      console.log('Game carregado');

      // Simula upload de BIOS e jogo
      await simulateFileSelect(biosBuffer, 'bios.bin');
      await simulateFileSelect(gameBuffer, 'game.bin');

      console.log('BIOS e jogo disparados para o emulador!');
    } catch (e) {
      console.error('Erro ao carregar automaticamente:', e);
    }
  }

  // Chama automaticamente após módulo ser carregado
  window.addEventListener('load', () => {
    autoLoad('bios.bin', 'game.bin');
  });

  return { autoLoad };
});