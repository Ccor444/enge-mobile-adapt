(() => {
  "use strict";

  let psxIndex = null;
  let cpuSpeedFactor = 1.2; // 20% mais rápido sem travar
  let biosData = null;
  let gameData = null;

  /**
   * Aguarda módulo principal do PSX estar disponível
   */
  const waitForPSX = async () => {
    while (!window.mdlr) await new Promise(r => setTimeout(r, 50));
    return new Promise(resolve => {
      const check = () => {
        const index = window.mdlr('enge:psx:index');
        if (index) {
          psxIndex = index;
          console.log('[PSX] Módulo encontrado');
          resolve(psxIndex);
        } else {
          setTimeout(check, 50);
        }
      };
      check();
    });
  };

  /**
   * Aplica overclock seguro no PSX
   */
  const applyOverclock = () => {
    if (!psxIndex) return console.warn('[Overclock] PSX não inicializado');
    const originalSpeed = psxIndex.PSX_SPEED;
    psxIndex.PSX_SPEED = originalSpeed * cpuSpeedFactor;
    console.log(`[Overclock] PSX_SPEED ajustado: ${originalSpeed.toFixed(2)} → ${psxIndex.PSX_SPEED.toFixed(2)}`);
  };

  /**
   * Lê arquivo como ArrayBuffer
   * @param {File} file 
   * @returns {Promise<ArrayBuffer>}
   */
  const loadFileAsync = (file) => new Promise((resolve, reject) => {
    if (!file) return reject('[loadFileAsync] Arquivo inválido');
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result);
    reader.onerror = e => reject(e);
    reader.readAsArrayBuffer(file);
  });

  /**
   * Carrega BIOS e ISO do game
   */
  const loadBiosAndGame = async () => {
    if (!biosData || !gameData) return console.warn('[Load] BIOS ou Game não definido');

    try {
      // Escrita da BIOS (modo rápido)
      const biosArray = new Uint8Array(biosData);
      const rom = window.rom;
      if (rom && rom.setInt32) {
        const len = biosArray.length;
        for (let i = 0; i < len; i += 4) {
          rom.setInt32(
            i,
            ((biosArray[i] || 0) << 24 | (biosArray[i + 1] || 0) << 16 | (biosArray[i + 2] || 0) << 8 | (biosArray[i + 3] || 0)) >>> 0,
            true
          );
        }
        console.log('[Load] BIOS carregada com sucesso');
      } else console.error('[Load] Módulo ROM não disponível');

      // Carregamento da ISO
      const cdrModule = window.cdr;
      if (cdrModule && cdrModule.setCdImage) {
        cdrModule.setCdImage(new DataView(gameData));
        console.log('[Load] Game ISO carregado com sucesso');
      } else console.error('[Load] Módulo CD-ROM não disponível');

    } catch (err) {
      console.error('[Load] Erro ao carregar arquivos:', err);
    }
  };

  /**
   * Inicializa menu interativo de arquivos
   */
  const initMenu = () => {
    const biosInput = document.getElementById('biosInput');
    const gameInput = document.getElementById('gameInput');

    if (biosInput) biosInput.addEventListener('change', e => biosData = e.target.files[0]);
    if (gameInput) gameInput.addEventListener('change', e => gameData = e.target.files[0]);

    // Função global para carregar arquivos manualmente
    window.loadFiles = async () => {
      if (biosData) biosData = await loadFileAsync(biosData);
      if (gameData) gameData = await loadFileAsync(gameData);
      await loadBiosAndGame();
    };
  };

  /**
   * Inicialização principal
   */
  (async () => {
    await waitForPSX();
    applyOverclock();
    initMenu();
    console.log('[PSX] Sistema pronto para uso');
  })();

})();