/*
  BIOS Injector Final + Notificação
  - Persiste BIOS no IndexedDB
  - Injeta automaticamente no storage do módulo
  - Notifica no modal se a BIOS foi localizada ou não
*/

const DB_NAME = 'enge_bios_db_v3';
const STORE = 'bios_store';
const BIOS_KEY = 'bios-dtlh3000';

async function openDb() {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

async function idbPut(key, value) {
  const db = await openDb();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(value, key);
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
  });
}

async function idbGet(key) {
  const db = await openDb();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get(key);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

// Notificação discreta no modal
function showBiosNotification(msg, duration = 2500) {
  const notif = document.getElementById('biosNotification');
  if (!notif) return;

  notif.textContent = msg;
  notif.classList.add('show');

  setTimeout(() => {
    notif.classList.remove('show');
  }, duration);
}

// Popula o input #file-upload com o arquivo BIOS
function populateFileInput(inputEl, bytes) {
  const file = new File([bytes], 'dtlh3000.bin', { type: 'application/octet-stream' });
  if (typeof DataTransfer !== 'undefined') {
    const dt = new DataTransfer();
    dt.items.add(file);
    inputEl.files = dt.files;
  } else {
    Object.defineProperty(inputEl, 'files', { value: [file], configurable: true });
  }
  inputEl.dispatchEvent(new Event('change', { bubbles: true }));
}

// Injeta a BIOS no módulo
function injectBios(arrayBuffer) {
  if (typeof window.writeStorageStream === 'function') {
    writeStorageStream('bios', arrayBuffer);
    console.log('[BIOS Injector] BIOS injetada no storage.');

    if (typeof window.bios === 'function') {
      try {
        window.bios();
        console.log('[BIOS Injector] bios() chamada com sucesso.');
      } catch(e) {
        console.warn('[BIOS Injector] erro ao chamar bios():', e);
      }
    }
    return true;
  }
  return false;
}

// Salva BIOS no IndexedDB e injeta
async function saveBios(arrayBuffer) {
  const bytes = arrayBuffer instanceof Uint8Array ? arrayBuffer : new Uint8Array(arrayBuffer);
  await idbPut(BIOS_KEY, bytes);
  injectBios(arrayBuffer);
}

// Restaura BIOS ao carregar a página
async function restoreBios() {
  const saved = await idbGet(BIOS_KEY);
  const input = document.querySelector('#file input[type="file"]') || document.getElementById('file-upload');

  if (!saved) {
    showBiosNotification('Nenhuma BIOS encontrada');
    return;
  }

  const bytes = saved instanceof Uint8Array ? saved : new Uint8Array(saved);
  const ab = bytes.buffer;

  const interval = setInterval(() => {
    if (injectBios(ab)) {
      clearInterval(interval);
      showBiosNotification('BIOS localizada e injetada com sucesso');
    }
  }, 300);

  setTimeout(() => clearInterval(interval), 30000);

  if (input) populateFileInput(input, bytes);
}

// Observa mudanças no input para salvar BIOS automaticamente
function attachInputHandler() {
  const input = document.querySelector('#file input[type="file"]') || document.getElementById('file-upload');
  if (!input || input.__biosHandlerAttached) return;
  input.__biosHandlerAttached = true;

  input.addEventListener('change', async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const ab = await f.arrayBuffer();
    const bytes = new Uint8Array(ab);

    if (bytes.length === 524288) {
      await idbPut(BIOS_KEY, bytes);
      injectBios(ab);
      console.log('[BIOS Injector] BIOS persistida e injetada automaticamente.');
      showBiosNotification('BIOS persistida e injetada automaticamente');
    } else {
      showBiosNotification('Arquivo selecionado não é uma BIOS válida');
    }
  });
}

// Inicialização
(function() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      attachInputHandler();
      restoreBios();
    });
  } else {
    attachInputHandler();
    restoreBios();
  }

  const fileDiv = document.getElementById('file');
  if (fileDiv) {
    new MutationObserver(() => attachInputHandler())
      .observe(fileDiv, { childList: true, subtree: true });
  }
})();
