
  (function () {
    // mask mapping conforme seu mdler
    const buttonMap = {
      up:     { byte: 'lo', mask: 0x10 },
      down:   { byte: 'lo', mask: 0x40 },
      left:   { byte: 'lo', mask: 0x80 },
      right:  { byte: 'lo', mask: 0x20 },
      select: { byte: 'lo', mask: 0x01 },
      start:  { byte: 'lo', mask: 0x08 },

      triangle: { byte: 'hi', mask: 0x10 },
      circle:   { byte: 'hi', mask: 0x20 },
      cross:    { byte: 'hi', mask: 0x40 },
      square:   { byte: 'hi', mask: 0x80 },

      l1: { byte: 'hi', mask: 0x04 },
      l2: { byte: 'hi', mask: 0x01 },
      r1: { byte: 'hi', mask: 0x08 },
      r2: { byte: 'hi', mask: 0x02 }
    };

    function getDevice() {
      if (window.joy && Array.isArray(joy.devices) && joy.devices[0]) return joy.devices[0];
      return null;
    }

    function ensureInit(dev, byte) {
      if (dev[byte] === undefined) dev[byte] = 0xff;
    }

    function callHandleGamePads() {
      try {
        if (typeof handleGamePads === 'function') handleGamePads();
      } catch (e) {
        // ignora se não existir
      }
    }

    // cria listeners para cada botão
    Object.keys(buttonMap).forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const { byte, mask } = buttonMap[id];

      const press = () => {
        const dev = getDevice();
        if (!dev) return;
        ensureInit(dev, byte);
        dev[byte] &= ~mask;
        callHandleGamePads();
      };

      const release = () => {
        const dev = getDevice();
        if (!dev) return;
        ensureInit(dev, byte);
        dev[byte] |= mask;
        callHandleGamePads();
      };

      // pointer events (unifica mouse/touch/pen)
      el.addEventListener('pointerdown', (e) => { e.preventDefault(); press(); });
      el.addEventListener('pointerup',   (e) => { e.preventDefault(); release(); });
      el.addEventListener('pointercancel', release);
      el.addEventListener('pointerleave',  release);

      // fallback touch events (alguns webviews)
      el.addEventListener('touchstart', (e) => { e.preventDefault(); press(); }, { passive: false });
      el.addEventListener('touchend',   (e) => { e.preventDefault(); release(); }, { passive: false });
      el.addEventListener('touchcancel', release);

      // evita menu de contexto em long-press
      el.addEventListener('contextmenu', (e) => e.preventDefault());
    });

    // Keyboard mapping (mesmo do seu mdler)
    const keyboard = new Map();
    // hi buttons (E D X S => tri circ x sq)
    keyboard.set(69, { bits: 0x10, property: 'hi' }); // E -> triangle
    keyboard.set(68, { bits: 0x20, property: 'hi' }); // D -> circle
    keyboard.set(88, { bits: 0x40, property: 'hi' }); // X -> cross
    keyboard.set(83, { bits: 0x80, property: 'hi' }); // S -> square
    // shoulders
    keyboard.set(81, { bits: 0x01, property: 'hi' }); // Q -> l2
    keyboard.set(84, { bits: 0x02, property: 'hi' }); // T -> r2
    keyboard.set(87, { bits: 0x04, property: 'hi' }); // W -> l1
    keyboard.set(82, { bits: 0x08, property: 'hi' }); // R -> r1
    // directions (arrows)
    keyboard.set(38, { bits: 0x10, property: 'lo' }); // up
    keyboard.set(39, { bits: 0x20, property: 'lo' }); // right
    keyboard.set(40, { bits: 0x40, property: 'lo' }); // down
    keyboard.set(37, { bits: 0x80, property: 'lo' }); // left
    // select/start
    keyboard.set(32, { bits: 0x01, property: 'lo' }); // space -> select
    keyboard.set(13, { bits: 0x08, property: 'lo' }); // enter -> start

    window.addEventListener('keydown', (e) => {
      const m = keyboard.get(e.keyCode);
      const dev = getDevice();
      if (!m || !dev) return;
      ensureInit(dev, m.property);
      dev[m.property] &= ~m.bits;
      callHandleGamePads();
      // evita scroll com espaço/alt etc
      if ([32,37,38,39,40].includes(e.keyCode)) e.preventDefault();
    }, false);

    window.addEventListener('keyup', (e) => {
      const m = keyboard.get(e.keyCode);
      const dev = getDevice();
      if (!m || !dev) return;
      ensureInit(dev, m.property);
      dev[m.property] |= m.bits;
      callHandleGamePads();
    }, false);

    // Quando a página perde foco, soltar todos (safety)
    window.addEventListener('blur', () => {
      const dev = getDevice();
      if (!dev) return;
      dev.lo = 0xff;
      dev.hi = 0xff;
      callHandleGamePads();
    });

  })();