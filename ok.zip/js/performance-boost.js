(() => {
  // ===============================
  // ⚡ PERFORMANCE BOOST MODULE ⚡
  // ===============================
  // Otimiza a execução do emulador (sem alterar os módulos originais)

  console.log('[PerformanceBoost] Inicializando otimizações...');

  const Perf = {
    fpsSamples: [],
    lastFrameTime: performance.now(),
    avgFPS: 0,
    maxSamples: 60,
    cpuBoostEnabled: false,
    gpuBoostEnabled: false,
    rafHooked: false,
  };

  // ===============================
  // 1️⃣ FPS MEDIÇÃO E AJUSTE DINÂMICO
  // ===============================
  Perf.trackFPS = function () {
    const now = performance.now();
    const delta = now - Perf.lastFrameTime;
    Perf.lastFrameTime = now;
    const fps = 1000 / delta;

    Perf.fpsSamples.push(fps);
    if (Perf.fpsSamples.length > Perf.maxSamples) Perf.fpsSamples.shift();

    Perf.avgFPS =
      Perf.fpsSamples.reduce((a, b) => a + b, 0) / Perf.fpsSamples.length;

    // Ajuste automático: se FPS cair muito, força modo rápido
    if (Perf.avgFPS < 30 && !Perf.cpuBoostEnabled) {
      Perf.enableCPUBoost();
    } else if (Perf.avgFPS > 50 && Perf.cpuBoostEnabled) {
      Perf.disableCPUBoost();
    }
  };

  // ===============================
  // 2️⃣ BOOST DE CPU (Throttle inteligente)
  // ===============================
  Perf.enableCPUBoost = function () {
    Perf.cpuBoostEnabled = true;
    console.log('[PerformanceBoost] CPU Boost ativado');
    if (window.SPU) SPU.sampleRate = 22050; // reduz carga sonora
    if (window.GPU) GPU.skipFrames = 1; // pula frames alternados
  };

  Perf.disableCPUBoost = function () {
    Perf.cpuBoostEnabled = false;
    console.log('[PerformanceBoost] CPU Boost desativado');
    if (window.SPU) SPU.sampleRate = 44100;
    if (window.GPU) GPU.skipFrames = 0;
  };

  // ===============================
  // 3️⃣ BOOST DE GPU (Render limpo e rápido)
  // ===============================
  Perf.enableGPUBoost = function () {
    Perf.gpuBoostEnabled = true;
    console.log('[PerformanceBoost] GPU Boost ativado');
    if (window.GPU && GPU.flush) {
      const originalFlush = GPU.flush;
      GPU.flush = function (...args) {
        if (Perf.avgFPS < 40) {
          // render simplificado
          return originalFlush.apply(this, args.slice(0, 1));
        }
        return originalFlush.apply(this, args);
      };
    }
  };

  // ===============================
  // 4️⃣ OTIMIZAÇÃO DE REQUESTANIMATIONFRAME
  // ===============================
  if (!Perf.rafHooked) {
    Perf.rafHooked = true;
    const originalRAF = window.requestAnimationFrame;
    window.requestAnimationFrame = function (cb) {
      return originalRAF(function (time) {
        Perf.trackFPS();
        cb(time);
      });
    };
  }

  // ===============================
  // 5️⃣ COLETOR DE LIXO (GC) PASSIVO
  // ===============================
  setInterval(() => {
    if (typeof globalThis.gc === 'function') {
      globalThis.gc();
      console.log('[PerformanceBoost] Garbage Collector acionado');
    }
  }, 10000);

  // ===============================
  // 6️⃣ AUTOBOOST AO INICIAR
  // ===============================
  setTimeout(() => {
    Perf.enableGPUBoost();
    console.log('[PerformanceBoost] Otimizações aplicadas com sucesso.');
  }, 1500);

  // Exporta globalmente (caso queira desativar manualmente)
  window.PerformanceBoost = Perf;

})();