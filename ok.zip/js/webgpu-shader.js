// webgpu-shader-advanced.js
// Ultra hardcore WebGPU + WebGL2 renderer com overlay discreto
const WebGPUShader = (() => {
  const ctx = {
    device: null,
    context: null,
    pipeline: null,
    sampler: null,
    bindGroupLayout: null,
    tripleBuffer: [],
    bufferIndex: 0,
    canvas: null,
    width: 640,
    height: 480,
    scaleMode: 'nearest',
    initialized: false,
    overlay: null,
    fps: { lastTime: performance.now(), frames: 0, fps: 0 },
    webgl: { gl: null, program: null, vertBuffer: null, texture: null }
  };

  // Shaders WGSL simples
  const vertWGSL = `
  struct VertexOut { @builtin(position) pos: vec4<f32>; @location(0) uv: vec2<f32>; };
  @vertex fn main(@builtin(vertex_index) vi: u32) -> VertexOut {
    var pos = array<vec2<f32>,6>( vec2<f32>(-1,-1), vec2<f32>(1,-1), vec2<f32>(-1,1),
                                   vec2<f32>(-1,1), vec2<f32>(1,-1), vec2<f32>(1,1) );
    var uv  = array<vec2<f32>,6>( vec2<f32>(0,1), vec2<f32>(1,1), vec2<f32>(0,0),
                                   vec2<f32>(0,0), vec2<f32>(1,1), vec2<f32>(1,0) );
    var out: VertexOut;
    out.pos = vec4<f32>(pos[vi],0,1);
    out.uv  = uv[vi];
    return out;
  }`;

  const fragWGSL = `
  @group(0) @binding(0) var mySampler: sampler;
  @group(0) @binding(1) var myTexture: texture_2d<f32>;
  @fragment fn main(@location(0) uv: vec2<f32>) -> @location(0) vec4<f32> {
    let c = textureSample(myTexture,mySampler,uv);
    return vec4<f32>(c.r, c.g, c.b, 1.0);
  }`;

  // Overlay discreto no canto inferior do canvas
  function createOverlay() {
    if(ctx.overlay) return ctx.overlay;
    if(!ctx.canvas) return null;

    const el = document.createElement('div');
    el.style.position = 'absolute';
    el.style.bottom = '2px';
    el.style.right = '2px';
    el.style.padding = '2px 4px';
    el.style.background = 'rgba(0,0,0,0.3)';
    el.style.color = '#0f0';
    el.style.fontFamily = 'monospace';
    el.style.fontSize = '11px';
    el.style.pointerEvents = 'none';
    el.style.zIndex = '999';
    ctx.canvas.parentElement.style.position = 'relative'; // garante posição para overlay
    ctx.canvas.parentElement.appendChild(el);

    ctx.overlay = el;
    return el;
  }

  function updateOverlay() {
    ctx.fps.frames++;
    const now = performance.now();
    if(now - ctx.fps.lastTime >= 1000){
      ctx.fps.fps = ctx.fps.frames;
      ctx.fps.frames = 0;
      ctx.fps.lastTime = now;
    }
    const mode = ctx.device ? 'GPU ON' : 'GPU OFF';
    const el = createOverlay();
    if(el) el.textContent = `${mode} | FPS: ${ctx.fps.fps}`;
  }

  // Init WebGPU
  async function initWebGPU(canvas){
    try{
      ctx.device = await (navigator.gpu?.requestAdapter()?.then(a=>a?.requestDevice()) || Promise.resolve(null));
      if(!ctx.device) throw 'No WebGPU';
      ctx.context = canvas.getContext('webgpu');
      ctx.context.configure({ device: ctx.device, format: navigator.gpu.getPreferredCanvasFormat(), alphaMode:'opaque' });

      ctx.bindGroupLayout = ctx.device.createBindGroupLayout({
        entries:[
          { binding:0, visibility:0x8, sampler:{} },
          { binding:1, visibility:0x8, texture:{} }
        ]
      });

      ctx.pipeline = ctx.device.createRenderPipeline({
        layout: ctx.device.createPipelineLayout({bindGroupLayouts:[ctx.bindGroupLayout]}),
        vertex:{ module: ctx.device.createShaderModule({code:vertWGSL}), entryPoint:'main' },
        fragment:{ module: ctx.device.createShaderModule({code:fragWGSL}), entryPoint:'main', targets:[{ format:navigator.gpu.getPreferredCanvasFormat() }] },
        primitive:{ topology:'triangle-list' }
      });

      ctx.sampler = ctx.device.createSampler({ magFilter:'nearest', minFilter:'nearest' });

      // Triple-buffering
      for(let i=0;i<3;i++)
        ctx.tripleBuffer[i] = ctx.device.createTexture({ size:[ctx.width,ctx.height,1], format:navigator.gpu.getPreferredCanvasFormat(), usage:0x10|0x4|0x8 });

      ctx.initialized = true;
      setInterval(updateOverlay, 100);
      return true;
    }catch(e){
      console.warn('WebGPU failed:', e);
      return false;
    }
  }

  // Fallback WebGL2
  function initWebGLFallback(canvas){
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    ctx.webgl.gl = gl;
    ctx.initialized = true;
    setInterval(updateOverlay, 100);
    return true;
  }

  // Public init
  async function init(canvas){
    ctx.canvas = canvas;
    const ok = await initWebGPU(canvas);
    if(!ok) initWebGLFallback(canvas);
    return true;
  }

  // Present frame ultra hardcore
  async function present(frame){
    if(!ctx.initialized) return;
    if(ctx.device && ctx.context){
      let tex = ctx.tripleBuffer[ctx.bufferIndex];
      ctx.bufferIndex = (ctx.bufferIndex+1)%3;

      if(frame instanceof Uint8Array){
        const imageData = new ImageData(new Uint8ClampedArray(frame.buffer), ctx.width, ctx.height);
        await ctx.device.queue.copyExternalImageToTexture({source:imageData},{texture:tex},[ctx.width,ctx.height,1]);
      } else {
        const img = frame instanceof ImageBitmap ? frame : await createImageBitmap(frame);
        await ctx.device.queue.copyExternalImageToTexture({source:img},{texture:tex},[img.width,img.height,1]);
      }

      const encoder = ctx.device.createCommandEncoder();
      const pass = encoder.beginRenderPass({ colorAttachments:[{ view:ctx.context.getCurrentTexture().createView(), loadOp:'clear', storeOp:'store', clearValue:{r:0,g:0,b:0,a:1} }] });
      const bindGroup = ctx.device.createBindGroup({ layout:ctx.bindGroupLayout, entries:[{binding:0,resource:ctx.sampler},{binding:1,resource:tex.createView()}] });
      pass.setPipeline(ctx.pipeline);
      pass.setBindGroup(0,bindGroup);
      pass.draw(6);
      pass.end();
      ctx.device.queue.submit([encoder.finish()]);
    }
  }

  return { init, present, info:ctx };
})();
window.WebGPUShader = WebGPUShader;