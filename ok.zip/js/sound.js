// sound.js
"use strict";

const SoundManager = (() => {
  let context = null;
  let gainNode = null;
  let buffer = null;
  let source = null;
  let left = null;
  let right = null;
  let frameCount = 0;
  let writeIndex = 0;

  // Volumes
  let mainVolumeLeft = 0.0;
  let mainVolumeRight = 0.0;
  let cdVolumeLeft = 0.0;
  let cdVolumeRight = 0.0;
  let extVolumeLeft = 0.0;
  let extVolumeRight = 0.0;

  // inicializa o áudio
  const init = (sampleRate = 44100, durationSec = 0.5) => {
    if (context) return;

    context = new AudioContext();
    gainNode = context.createGain();
    frameCount = Math.floor(sampleRate * durationSec);

    buffer = context.createBuffer(2, frameCount, context.sampleRate);
    left = buffer.getChannelData(0);
    right = buffer.getChannelData(1);
    left.fill(0);
    right.fill(0);

    source = context.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    source.playbackRate.value = sampleRate / context.sampleRate;

    source.connect(gainNode);
    gainNode.connect(context.destination);
    source.start();
  };

  // clamping + dithering para fidelidade PS1
  const clamp = (v) => {
    // dither simples
    const dither = (Math.random() - 0.5) / 65536;
    return Math.max(-1.0, Math.min(1.0, v + dither));
  };

  // escreve amostra com mixagem completa
  const writeSample = (l, r, options = {}) => {
    if (!left || !right) return;

    let finalL = 0, finalR = 0;

    // mistura volumes
    finalL += (l * (options.mainLeft ?? mainVolumeLeft));
    finalR += (r * (options.mainRight ?? mainVolumeRight));

    finalL += (l * (options.cdLeft ?? cdVolumeLeft));
    finalR += (r * (options.cdRight ?? cdVolumeRight));

    finalL += (l * (options.extLeft ?? extVolumeLeft));
    finalR += (r * (options.extRight ?? extVolumeRight));

    left[writeIndex] = clamp(finalL);
    right[writeIndex] = clamp(finalR);

    writeIndex = (writeIndex + 1) % frameCount;
  };

  // limpa buffer
  const silence = () => {
    if (!left || !right) return;
    left.fill(0);
    right.fill(0);
  };

  // configura volumes
  const setVolume = ({mainL, mainR, cdL, cdR, extL, extR}) => {
    if (mainL !== undefined) mainVolumeLeft = mainL;
    if (mainR !== undefined) mainVolumeRight = mainR;
    if (cdL !== undefined) cdVolumeLeft = cdL;
    if (cdR !== undefined) cdVolumeRight = cdR;
    if (extL !== undefined) extVolumeLeft = extL;
    if (extR !== undefined) extVolumeRight = extR;
  };

  // plug-in de efeito externo (ex: reverb, EQ)
  let effectFn = null;
  const setEffect = (fn) => { effectFn = fn; };
  const processEffect = (l, r) => effectFn ? effectFn(l, r) : [l, r];

  // writeSample avançado com efeito
  const writeSampleEffect = (l, r, options = {}) => {
    [l, r] = processEffect(l, r);
    writeSample(l, r, options);
  };

  return {
    init,
    writeSample,
    writeSampleEffect,
    silence,
    setVolume,
    setEffect,
    isReady: () => !!context,
    get frameCount() { return frameCount; },
  };
})();

// expose global
window.SoundManager = SoundManager;

// --- EXEMPLO DE USO ---
// SoundManager.init();
// SoundManager.setVolume({mainL:0.7, mainR:0.7, cdL:0.5, cdR:0.5});
// SoundManager.writeSampleEffect(leftSample, rightSample);
// SoundManager.setEffect((l,r)=>[l*0.9,r*0.9]); // efeito simples