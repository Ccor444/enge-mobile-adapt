(() => {
    // ======= Utilitário de espera =======
    const waitFor = (conditionFn, interval = 100, timeout = 5000) => {
        return new Promise((resolve, reject) => {
            const start = Date.now();
            const check = () => {
                if (conditionFn()) return resolve(conditionFn());
                if (Date.now() - start > timeout) return reject('Timeout');
                setTimeout(check, interval);
            };
            check();
        });
    };

    // ======= Inicialização =======
    waitFor(() => document.querySelector('#settingsModal .modal-content'))
    .then(modalContent => waitFor(() => window.psx?.modules?.get('enge:psx:dma')?.dma)
    .then(dmaModule => {
        // ======= Painel Debug =======
        const panel = document.createElement('div');
        panel.id = 'dmaDebugPanel';
        panel.style.cssText = `
            margin-top:20px; padding:12px; background:#1e1e1e; color:#0f0;
            border-radius:10px; font-family:monospace; font-size:13px;
        `;
        panel.innerHTML = `
            <h6 style="margin-bottom:8px;">🎮 DMA Debug Avançado</h6>
            <label><input type="checkbox" id="dmaEnable" checked> Ativar Debug</label>
            <label><input type="checkbox" id="dmaWr32" checked> Log wr32</label>
            <label><input type="checkbox" id="dmaRd32" checked> Log rd32</label>
            <div id="dmaLog" style="
                margin-top:10px; max-height:250px; overflow-y:auto;
                background:#111; padding:8px; border-radius:6px; font-size:12px; color:#0f0;
                white-space:pre-wrap;
            "></div>
        `;
        modalContent.appendChild(panel);

        const logEl = document.getElementById('dmaLog');
        const enableSwitch = document.getElementById('dmaEnable');
        const wr32Switch = document.getElementById('dmaWr32');
        const rd32Switch = document.getElementById('dmaRd32');

        // ======= Função de log =======
        const log = (...args) => {
            if (!enableSwitch.checked) return;
            console.log('[DMA DEBUG]', ...args);
            logEl.textContent += `[${new Date().toLocaleTimeString()}] ${args.join(' ')}\n`;
            logEl.scrollTop = logEl.scrollHeight;
        };

        // ======= Proxy avançado nos métodos =======
        const wrapDMA = (obj, fnName, checkSwitch) => {
            if (!obj[fnName]) return;
            const orig = obj[fnName];
            obj[fnName] = new Proxy(orig, {
                apply(target, thisArg, args) {
                    if (checkSwitch.checked) log(`${fnName} chamado com:`, ...args);
                    const ret = Reflect.apply(target, thisArg, args);
                    if (checkSwitch.checked) log(`${fnName} retorno:`, ret);
                    return ret;
                }
            });
        };

        wrapDMA(dmaModule, 'wr32', wr32Switch);
        wrapDMA(dmaModule, 'rd32', rd32Switch);
        wrapDMA(dmaModule, 'wr08', enableSwitch);
        wrapDMA(dmaModule, 'rd08', enableSwitch);
        wrapDMA(dmaModule, 'wr16', enableSwitch);
        wrapDMA(dmaModule, 'rd16', enableSwitch);

        // ======= Monitoramento de IRQ =======
        const irqCheck = () => {
            if (!enableSwitch.checked) return;
            try {
                const dicr = dmaModule.dpcr || 0;
                const irq = dmaModule.dicr || 0;
                log('IRQ/DPCR Snapshot:', { dpcr: dicr, dicr: irq });
            } catch(e) { log('Erro ao ler IRQ:', e); }
            requestAnimationFrame(irqCheck);
        };
        irqCheck();

        log('✅ DMA Debug Avançado Ativo!');
    }))
    .catch(err => console.warn('DMA Debug não inicializado:', err))
})();