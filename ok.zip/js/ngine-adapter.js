(() => {
  // ==========================================
  // 🧩 N-GINE ADAPTER – ponte entre o emulador e os módulos externos
  // ==========================================
  console.log('[NgineAdapter] Inicializando camada de compatibilidade...');

  const Adapter = {
    hooks: {},
    state: {
      fps: 0,
      speed: 1.0,
      frameTime: 0,
      running: false,
      lastTime: performance.now(),
      frameCount: 0,
      lastFPSUpdate: performance.now(),
    }
  };

  // ==========================================
  // 🔌 Sistema de Hooks e Eventos Globais
  // ==========================================
  Adapter.on = function (event, callback) {
    if (!this.hooks[event]) this.hooks[event] = [];
    this.hooks[event].push(callback);
  };

  Adapter.emit = function (event, data) {
    if (this.hooks[event]) {
      this.hooks[event].forEach(cb => {
        try {
          cb(data);
        } catch (err) {
          console.error(`[NgineAdapter] Erro no hook ${event}:`, err);
        }
      });
    }
  };

  // ==========================================
  // ⚙️ Hook de Loop de Emulação
  // ==========================================
  const hookFrame = (time) => {
    const s = Adapter.state;
    const delta = time - s.lastTime;
    s.lastTime = time;
    s.frameTime = delta;
    s.frameCount++;

    // Atualiza FPS a cada 500ms
    if (time - s.lastFPSUpdate >= 500) {
      s.fps = (s.frameCount * 1000) / (time - s.lastFPSUpdate);
      s.frameCount = 0;
      s.lastFPSUpdate = time;
      Adapter.emit('fps', s.fps);
    }

    // Envia estado geral para outros módulos
    Adapter.emit('frame', { fps: s.fps, delta, running: s.running });
    requestAnimationFrame(hookFrame);
  };

  // ==========================================
  // 🚀 Inicialização automática
  // ==========================================
  Adapter.init = function () {
    console.log('[NgineAdapter] Monitorando ciclo do emulador...');
    Adapter.state.running = true;
    requestAnimationFrame(hookFrame);

    // Intercepta erros globais
    window.addEventListener('error', (err) => {
      Adapter.emit('error', err.message || err);
    });

    // Se o emulador emitir logs, repassa para o logcast
    const originalLog = window.log || console.log;
    window.log = (...args) => {
      originalLog(...args);
      Adapter.emit('log', args.join(' '));
    };
  };

  // ==========================================
  // 📡 Integração com PerformanceBoost e Logcast
  // ==========================================
  Adapter.on('fps', (fps) => {
    if (window.PerformanceBoost) {
      window.PerformanceBoost.avgFPS = fps;
    }
    if (window.logcastActive) {
      const info = `[FPS] ${fps.toFixed(1)} | [Speed] ${Adapter.state.speed.toFixed(2)}x`;
      Adapter.emit('log', info);
    }
  });

  Adapter.on('error', (msg) => {
    if (window.logcastActive) {
      Adapter.emit('log', `[ERRO] ${msg}`);
    }
  });

  // ==========================================
  // 📈 Sincronização de velocidade de emulação
  // ==========================================
  Adapter.setSpeed = function (multiplier) {
    Adapter.state.speed = multiplier;
    if (window.psx && psx.PSX_SPEED) {
      psx.PSX_SPEED *= multiplier;
    }
    Adapter.emit('log', `[NgineAdapter] Velocidade ajustada para ${multiplier.toFixed(2)}x`);
  };

  // ==========================================
  // 🧠 Exposição Global
  // ==========================================
  window.NgineAdapter = Adapter;
  Adapter.init();
})();