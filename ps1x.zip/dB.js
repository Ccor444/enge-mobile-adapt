// dB.js — Disc Database Manager atualizado
console.log('[dB] Inicializando injeção do discDB...');

const DiscDB = (() => {
    // Estado interno do discDB
    let db = {};
    let loaded = false;

    // Função para carregar o YAML do discDB
    async function loadDB(url = 'discdb.yaml') {
        try {
            const res = await fetch(url);
            if (!res.ok) throw new Error(`Falha ao carregar ${url}: ${res.status}`);
            const text = await res.text();

            // Parse simples de YAML para objeto JS
            db = parseYAML(text);
            loaded = true;
            console.log('[dB] discDB carregado com sucesso:', Object.keys(db).length, 'entradas');
        } catch (err) {
            console.error('[dB] Erro ao carregar discDB:', err);
        }
    }

    // Função de parse YAML simples (para evitar libs externas)
    function parseYAML(yamlText) {
        const lines = yamlText.split('\n').filter(l => l.trim() && !l.trim().startsWith('#'));
        const obj = {};
        let currentKey = null;

        lines.forEach(line => {
            if (/^\S/.test(line)) {
                const [key, value] = line.split(':').map(s => s.trim());
                currentKey = key;
                obj[key] = value || {};
            } else if (currentKey) {
                const match = line.match(/^\s+(\S+):\s*(.+)$/);
                if (match) {
                    const [, k, v] = match;
                    obj[currentKey][k] = v;
                }
            }
        });
        return obj;
    }

    // Busca entrada no discDB pelo serial do disco
    function find(serial) {
        if (!loaded) {
            console.warn('[dB] discDB ainda não carregado. Retornando nulo.');
            return null;
        }
        return db[serial] || null;
    }

    // Integração com CDR (para injetar dados de disco)
    function attachCDR(cdrModule) {
        if (!cdrModule) {
            console.warn('[dB] Módulo CDR não fornecido.');
            return;
        }

        cdrModule.onDiscLoad = (serial) => {
            const entry = find(serial);
            if (entry) {
                console.log('[dB] Disco reconhecido:', serial, entry);
                // Aplicar dados do discDB ao CDR
                cdrModule.setDiscMetadata(entry);
            } else {
                console.warn('[dB] Disco não encontrado no discDB:', serial);
            }
        };
    }

    return {
        loadDB,
        find,
        attachCDR,
    };
})();

// Auto-load
DiscDB.loadDB();

// Export (se for usado em módulos)
if (typeof window !== 'undefined') window.DiscDB = DiscDB;
if (typeof module !== 'undefined') module.exports = DiscDB;